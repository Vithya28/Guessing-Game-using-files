import random
import os

stage = 1
getname=str(input("Enter the Player Name : "))
#print(getname)

FilePath =str(os.getcwd())

from pathlib import Path
my_file = Path(FilePath+"\\"+getname+".txt")
#print(my_file);
#if (my_file.is_file()==False):
if (my_file.exists()==False):
  #print('11')
  fi =  open(getname+".txt", "w")
  fi.write(str(stage-1))
  fi.close()
else:
  #print('12')
  r =  open(getname+".txt", "r")
  read=r.read()
  stage = int(read)+1

#print("stage value " +str(stage))

incStage = stage
endStage = 10
chances = 5
low = 1
high = 10

while(stage <= endStage):
    #print("hi")
    if(stage == incStage):
        t = 0
        x = random.randint(low, high)
        print(x)
        
        print("________________________ Stage " + str(stage) + " ________________________")
        num = int(input("Guess a Number between " + str(low) + " & " + str(high) + " : "))
        while (x != 'n'):
            f =  open(getname+".txt", "w")
            f.write(str(stage))
            f.close()
            if(t<(chances-1)):
                if num < x:
                    print("The number guessed is low")
                    t = t + 1
                    num = int(input("Guess again : "))
                elif (num > x):
                    print("The number guessed is high")
                    t = t + 1
                    num = int(input("Guess again : "))
                else:
                    print("Your Guess is Correct")
                    t = t + 1
                    stage+=1
                    incStage+=1
                    high+=10
                    break
            else:
                print("Game Over")
                f =  open(getname+".txt", "w")
                f.write(str(stage-1))
                f.close()
                quit()
                break
                
print("You Won")
